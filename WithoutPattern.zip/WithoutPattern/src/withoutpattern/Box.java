package withoutpattern;

import java.util.ArrayList;
import java.util.List;

public class Box {
    private String name;
  
    private List<Product> products = new ArrayList<>(); 
    private List<Box> innerBoxes = new ArrayList<>();

    public Box(String name) { this.name = name; }

   
    public void addProduct(Product p) { products.add(p); }
    public void addBox(Box b) { innerBoxes.add(b); }

    public double calculateTotalPrice() {
        double total = 0;
   
        for (Product p : products) {
            total += p.getPrice();
        }
        for (Box inner : innerBoxes) {
            total += inner.calculateTotalPrice();
        }
        return total;
    }

    public String getName() { return name; }
}