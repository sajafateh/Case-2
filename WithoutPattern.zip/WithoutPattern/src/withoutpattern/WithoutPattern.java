package withoutpattern;

public class WithoutPattern {


    public static void main(String[] args) {
        Product laptop = new Product("Laptop", 999.0);
        Product mouse = new Product("Mouse", 25.0);
        Product sticker = new Product("Sticker", 2.0);

        Box tinyBox = new Box("TinyBox");
        tinyBox.addProduct(sticker); 

        Box motherBox = new Box("MotherBox");
        motherBox.addProduct(laptop);
        motherBox.addProduct(mouse);
        motherBox.addBox(tinyBox); 

        double total = motherBox.calculateTotalPrice();
        System.out.printf("Total Price: $%.2f%n", total); 
    }
}