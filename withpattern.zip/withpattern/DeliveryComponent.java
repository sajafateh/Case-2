
package withpattern;


public interface DeliveryComponent {
    double getPrice(); 
    String getName(); 
    void display(String indent);
}