
package withpattern;


public class Product implements DeliveryComponent {
    private String name;
    private double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public double getPrice() { return price; } 

    @Override
    public String getName() { return name; }

    @Override
    public void display(String indent) {
        System.out.printf("%s[Product] %-15s $%.2f%n", indent, name, price);
    }
}