package withpattern;

import java.util.ArrayList;
import java.util.List;

public class Box implements DeliveryComponent {
    private String name;
    private List<DeliveryComponent> children = new ArrayList<>(); 

    public Box(String name) { this.name = name; }

    public void add(DeliveryComponent c) { children.add(c); } 
    public void remove(DeliveryComponent c) { children.remove(c); }

    @Override
    public double getPrice() {
        double total = 0;
        for (DeliveryComponent child : children) {
            total += child.getPrice(); 
        }
        return total;
    }

    @Override
    public String getName() { return name; }

    @Override
    public void display(String indent) {
        System.out.printf("%s [Box] %s (subtotal: $%.2f)%n", indent, name, getPrice());
        for (DeliveryComponent child : children) {
            child.display(indent + "  ");
        }
    }
}