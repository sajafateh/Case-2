
package withpattern;


public class DeliveryOrder {
    private String orderId;
    private DeliveryComponent rootComponent;

    public DeliveryOrder(String orderId, DeliveryComponent rootComponent) {
        this.orderId = orderId;
        this.rootComponent = rootComponent;
    }

    public double calculateTotal() {
        return rootComponent.getPrice();
    }

    public void printOrderSummary() {
        System.out.println("Order ID: " + orderId);
        rootComponent.display("");
        System.out.printf("TOTAL: $%.2f%n", calculateTotal());
    }
}