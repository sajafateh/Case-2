package withpattern;

public class WithPattern {

    public static void main(String[] args) {


        Product laptop = new Product("Laptop", 999.0);
        Product mouse = new Product("Mouse", 25.0);
        Product sticker = new Product("Sticker", 2.0);

     
        Box tinyBox = new Box("TinyBox");
        tinyBox.add(sticker);

        Box motherBox = new Box("MotherBox");
        motherBox.add(laptop);
        motherBox.add(mouse);
        motherBox.add(tinyBox);

      
        DeliveryOrder order = new DeliveryOrder("ORD-2026", motherBox);
        order.printOrderSummary();
    }
}